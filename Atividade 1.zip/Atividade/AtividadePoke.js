// Função para mostrar as abas
function showTab(tabName) {
    const contents = document.querySelectorAll(".tab-content");
    contents.forEach((content) =>
        content.classList.remove("active")
    );
    document.getElementById(tabName).classList.add("active");
}

// Função para buscar informações de um Pokémon
async function fetchPokemon() {
    const pokemonInput = document
        .getElementById("pokemonInput")
        .value.toLowerCase();
    const url = `https://pokeapi.co/api/v2/pokemon/${pokemonInput}`;
    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error("Pokémon não encontrado");
        const pokemon = await response.json();
        displayPokemon(pokemon);
    } catch (error) {
        displayError(error.message, "pokemonInfo");
    }
}

function displayPokemon(pokemon) {
    const pokemonInfo = document.getElementById("pokemonInfo");
    pokemonInfo.innerHTML = `
<h2>${
    pokemon.name.charAt(0).toUpperCase() + pokemon.name.slice(1)
}</h2>
<img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${pokemon.id}.png" alt="${pokemon.name}">
<p><strong>ID:</strong> ${pokemon.id}</p>
<p><strong>Tipo:</strong> ${pokemon.types
    .map((type) => type.type.name)
    .join(", ")}</p>
<p><strong>Altura:</strong> ${pokemon.height / 10} m</p>
<p><strong>Peso:</strong> ${pokemon.weight / 10} kg</p>
`;
}

function displayError(message, elementId) {
    const element = document.getElementById(elementId);
    element.innerHTML = `<p style="color: red;">${message}</p>`;
}

// Listar os primeiros 150 Pokémon
async function listPokemon() {
    const url = `https://pokeapi.co/api/v2/pokemon?limit=150`;
    const response = await fetch(url);
    const data = await response.json();
    const pokemonList = document.getElementById("pokemonList");
    pokemonList.innerHTML = data.results
        .map(
            (pokemon) => `
<div>
    <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${
        pokemon.url.split("/")[6]
    }.png" alt="${pokemon.name}">
    <p>${
        pokemon.name.charAt(0).toUpperCase() + pokemon.name.slice(1)
    }</p>
</div>
`
        )
        .join("");
}


// Filtrar Pokémon por tipo
async function filterPokemon() {
    const filterType = document
        .getElementById("filterType")
        .value.toLowerCase();
    const url = `https://pokeapi.co/api/v2/type/${filterType}`;
    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error("Tipo não encontrado");
        const data = await response.json();
        const pokemonList = document.getElementById("pokemonList");
        pokemonList.innerHTML = data.pokemon
            .map(
                (pokemon) => `
    <div>
        <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${
            pokemon.pokemon.url.split("/")[6]
        }.png" alt="${pokemon.pokemon.name}">
        <p>${
            pokemon.pokemon.name.charAt(0).toUpperCase() +
            pokemon.pokemon.name.slice(1)
        }</p>
    </div>
`
            )
            .join("");
    } catch (error) {
        displayError(error.message, "pokemonList");
    }
}

// Comparar dois Pokémon
async function comparePokemon() {
    const pokemonOne = document
        .getElementById("pokemonOne")
        .value.toLowerCase();
    const pokemonTwo = document
        .getElementById("pokemonTwo")
        .value.toLowerCase();

    const urlOne = `https://pokeapi.co/api/v2/pokemon/${pokemonOne}`;
    const urlTwo = `https://pokeapi.co/api/v2/pokemon/${pokemonTwo}`;

    try {
        const [responseOne, responseTwo] = await Promise.all([
            fetch(urlOne),
            fetch(urlTwo),
        ]);
        if (!responseOne.ok || !responseTwo.ok)
            throw new Error("Pokémon não encontrados");
        const dataOne = await responseOne.json();
        const dataTwo = await responseTwo.json();

        displayComparison(dataOne, dataTwo);
    } catch (error) {
        displayError(error.message, "compareResult");
    }
}

function displayComparison(pokemonOne, pokemonTwo) {
    const compareResult = document.getElementById("compareResult");
    
    // Formando o link do GIF baseado no ID do Pokémon
    const gifUrlOne = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/animated/132.gif`.replace("132", pokemonOne.id);
    const gifUrlTwo = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/animated/132.gif`.replace("132", pokemonTwo.id);

    compareResult.innerHTML = `
<h3>Comparação entre ${
    pokemonOne.name.charAt(0).toUpperCase() +
    pokemonOne.name.slice(1)
} e ${
        pokemonTwo.name.charAt(0).toUpperCase() +
        pokemonTwo.name.slice(1)
    }</h3>
<div class="nome">
<div>
    <img src="${gifUrlOne}" alt="${pokemonOne.name}">
    <p><strong>ID:</strong> ${pokemonOne.id}</p>
    <p><strong>Altura:</strong> ${pokemonOne.height / 10} m</p>
    <p><strong>Peso:</strong> ${pokemonOne.weight / 10} kg</p>
</div>
<div>
    <img src="${gifUrlTwo}" alt="${pokemonTwo.name}">
    <p><strong>ID:</strong> ${pokemonTwo.id}</p>
    <p><strong>Altura:</strong> ${pokemonTwo.height / 10} m</p>
    <p><strong>Peso:</strong> ${pokemonTwo.weight / 10} kg</p>
</div>
</div>
`;
}


let currentQuestion = 0;
const questions = [
    {
        question:
            "Qual Pokémon é conhecido como o 'Pokémon Lendário do Tempo'?",
        answer: "dialga",
    },
    {
        question: "Qual Pokémon evolui de Charmander?",
        answer: "charmeleon",
    },
    {
        question:
            "Qual Pokémon tem a habilidade de voar e é o 'Pokémon Lendário do Vento'?",
        answer: "articuno",
    },
];

function startQuiz() {
    currentQuestion = 0;
    askQuestion();
}

function askQuestion() {
    if (currentQuestion < questions.length) {
        const quizContainer =
            document.getElementById("quizContainer");
        quizContainer.innerHTML = `
    <p>${questions[currentQuestion].question}</p>
    <input type="text" id="quizAnswer" placeholder="Resposta">
    <button onclick="checkAnswer()">Responder</button>
`;
    } else {
        const quizContainer =
            document.getElementById("quizContainer");
        quizContainer.innerHTML =
            "<p>Você completou o quiz! Parabéns!</p>";
    }
}

function checkAnswer() {
    const userAnswer = document
        .getElementById("quizAnswer")
        .value.toLowerCase();
    const correctAnswer = questions[currentQuestion].answer;

    if (userAnswer === correctAnswer) {
        currentQuestion++;
        askQuestion();
    } else {
        alert("Resposta incorreta. Tente novamente.");
    }
}

// Explorador de Habilidades
async function listAbilities() {
    const url = `https://pokeapi.co/api/v2/ability`;
    const response = await fetch(url);
    const data = await response.json();
    const abilityList = document.getElementById("abilityList");
    abilityList.innerHTML = data.results
        .map(
            (ability) => `
<div>
    <p>${
        ability.name.charAt(0).toUpperCase() + ability.name.slice(1)
    }</p>
</div>
`
        )
        .join("");
}

// Mapa de Localização Pokémon
async function fetchLocation() {
    const pokemonInput = document
        .getElementById("locationInput")
        .value.toLowerCase();
    const url = `https://pokeapi.co/api/v2/pokemon/${pokemonInput}`;
    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error("Pokémon não encontrado");
        const data = await response.json();
        const locationInfo =
            document.getElementById("locationInfo");
        const locations = data.game_indices
            .map((game) => game.version.name)
            .join(", ");
        locationInfo.innerHTML = `
    <h3>Locais onde ${
        data.name.charAt(0).toUpperCase() + data.name.slice(1)
    } pode ser encontrado:</h3>
    <p>${locations}</p>
`;
    } catch (error) {
        displayError(error.message, "locationInfo");
    }
}

// Simulador de Batalhas Pokémon
async function simulateBattle() {
    const pokemonOne = document
        .getElementById("pokemonBattleOne")
        .value.toLowerCase();
    const pokemonTwo = document
        .getElementById("pokemonBattleTwo")
        .value.toLowerCase();

    const urlOne = `https://pokeapi.co/api/v2/pokemon/${pokemonOne}`;
    const urlTwo = `https://pokeapi.co/api/v2/pokemon/${pokemonTwo}`;

    try {
        const [responseOne, responseTwo] = await Promise.all([
            fetch(urlOne),
            fetch(urlTwo),
        ]);
        if (!responseOne.ok || !responseTwo.ok)
            throw new Error("Pokémon não encontrados");
        const dataOne = await responseOne.json();
        const dataTwo = await responseTwo.json();

        const battleResult =
            document.getElementById("battleResult");
        let winner =
            dataOne.stats[0].base_stat > dataTwo.stats[0].base_stat
                ? dataOne.name
                : dataTwo.name;

        battleResult.innerHTML = `
    <h3>Batalha entre ${
        dataOne.name.charAt(0).toUpperCase() + dataOne.name.slice(1)
    } e ${
            dataTwo.name.charAt(0).toUpperCase() +
            dataTwo.name.slice(1)
        }</h3>
    <div>
        <img src="${dataOne.sprites.front_default}" alt="${
            dataOne.name
        }">
        <p>${
            dataOne.name.charAt(0).toUpperCase() +
            dataOne.name.slice(1)
        }</p>
        <p><strong>HP:</strong> ${dataOne.stats[0].base_stat}</p>
    </div>
    <div>
        <img src="${dataTwo.sprites.front_default}" alt="${
            dataTwo.name
        }">
        <p>${
            dataTwo.name.charAt(0).toUpperCase() +
            dataTwo.name.slice(1)
        }</p>
        <p><strong>HP:</strong> ${dataTwo.stats[0].base_stat}</p>
    </div>
    <p><strong>Vencedor:</strong> ${
        winner.charAt(0).toUpperCase() + winner.slice(1)
    }</p>
`;
    } catch (error) {
        displayError(error.message, "battleResult");
    }
}

// Enciclopédia de Tipos de Pokémon
async function listTypes() {
    const url = `https://pokeapi.co/api/v2/type`;
    const response = await fetch(url);
    const data = await response.json();
    const typeInfo = document.getElementById("typeInfo");
    typeInfo.innerHTML = data.results
        .map(
            (type) => `
<div>
    <p>${type.name.charAt(0).toUpperCase() + type.name.slice(1)}</p>
</div>
`
        )
        .join("");
}

// Árvore de Evolução
// Árvore de Evolução
async function fetchEvolution() {
    const pokemonInput = document
        .getElementById("evolutionInput")
        .value.toLowerCase();
    const url = `https://pokeapi.co/api/v2/pokemon-species/${pokemonInput}`;
    try {
        const response = await fetch(url);

        if (!response.ok) throw new Error("Pokémon não encontrado");
        const data = await response.json();

        const evolutionChainUrl = data.evolution_chain.url;
        const evolutionResponse = await fetch(evolutionChainUrl);
        const evolutionData = await evolutionResponse.json();

        const evolutionTree = document.getElementById("evolutionTree");
        const evolution = evolutionData.chain;
        let evolutionHtml = `<h3>Árvore de Evolução de ${
            data.name.charAt(0).toUpperCase() + data.name.slice(1)
        }:</h3>`;
        let evolutionList = await getEvolutionChain(evolution);

        evolutionHtml += `<ul>${evolutionList
            .map(
                (evo) =>
                    `<li>
                        <img src="${evo.imageUrl}" alt="${evo.name}" width="100">
                        <p>${evo.name.charAt(0).toUpperCase() + evo.name.slice(1)}</p>
                    </li>`
            )
            .join("")}</ul>`;
        evolutionTree.innerHTML = evolutionHtml;
    } catch (error) {
        displayError(error.message, "evolutionTree");
    }
}

async function getEvolutionChain(evolution) {
    let chain = [];
    const speciesName = evolution.species.name;
    const speciesUrl = `https://pokeapi.co/api/v2/pokemon/${speciesName}`;
    const response = await fetch(speciesUrl);
    const speciesData = await response.json();

    // Adicionando o nome e a imagem do Pokémon
    chain.push({
        name: speciesName,
        imageUrl: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${speciesData.id}.png`
    });

    if (evolution.evolves_to.length > 0) {
        for (const evo of evolution.evolves_to) {
            const evolutionChain = await getEvolutionChain(evo);
            chain = chain.concat(evolutionChain);
        }
    }

    return chain;
}


// Construtor de Equipes Pokémon
const team = [];

function addToTeam() {
    const teamInput = document
        .getElementById("teamInput")
        .value.toLowerCase();
    const url = `https://pokeapi.co/api/v2/pokemon/${teamInput}`;
    fetch(url)
        .then((response) => response.json())
        .then((data) => {
            if (team.length < 6) {
                team.push(data);
                displayTeam();
            } else {
                alert("Sua equipe já está cheia! (6 Pokémon)");
            }
        })
        .catch((error) => {
            alert("Pokémon não encontrado.");
        });
}

function displayTeam() {
    const teamDisplay = document.getElementById("teamDisplay");
    teamDisplay.innerHTML = team
        .map(
            (pokemon) => `
<div>
    <img src="${pokemon.sprites.front_default}" alt="${
                pokemon.name
            }">
    <p>${
        pokemon.name.charAt(0).toUpperCase() + pokemon.name.slice(1)
    }</p>
</div>
`
        )
        .join("");
}